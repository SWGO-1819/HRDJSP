/**
 * 
 */
window.onload = function() {
	var btnclick = getElementById("btnclick");
	var form = getElementById("frm");
	btnclick.onclick= function(){
		for(var i=0;i<7;i++){
			if(form[i].value==""){
				switch(i){
				case 2:
					alert("판매구분이 비었습니다");
					break;
				case 3:
					alert("판매점포이 비었습니다");
					break;
				case 4:
					alert("판매상품이 비었습니다");
					break;
				case 5:
					alert("판매수량이 비었습니다");
					break;
				case 6:
					alert("수취구분이 비었습니다");
					break;
				}
				form[i].focus();
			}
		}
	}
}