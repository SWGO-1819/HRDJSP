package DBPKG;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
public class DBconnection {
	public static Connection getConnection() throws Exception{
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521/xe";
		String user="system";
		String password = "asd123";
		try{
			Connection conn =null;
			Class.forName(driver);
			conn=DriverManager.getConnection(url,user,password);
			return conn;
		}catch(ClassNotFoundException e1){
			System.out.println("로딩실패");
		}catch(SQLException e2){
			System.out.println("연결실패");
		}
		return null;
	}
	public static ResultSet exec_sql(String aql,String type) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		conn=DBconnection.getConnection();
		
		pstmt=conn.prepareStatement(aql);
		if(type.equals("select")){
			rs = pstmt.executeQuery();
			return rs;
		}else if(type.equals("update")){
			pstmt.executeUpdate();
		}
		return null;
	}
}
