package DBPKG;
import java.sql.*;
public class DBconnection {
	public static Connection getConnection() throws Exception{
		Connection conn=null;
		Class.forName("oracle.jdbc.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","1234");
		return conn;
	}
	public static ResultSet getSql(String sql, String types) throws Exception{
		ResultSet rs =null;
		System.out.println(sql);
		Connection conn=getConnection();
		PreparedStatement ptsmt = null;
		ptsmt=conn.prepareStatement(sql);
		if(types.equals("select")) {
			rs=ptsmt.executeQuery();
		}
		else if(types.equals("insert")||types.equals("update")) {
			ptsmt.executeUpdate();
		}
		return rs;
	}
}
