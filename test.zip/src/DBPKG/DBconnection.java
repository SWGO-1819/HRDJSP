package DBPKG;
import java.sql.*;
public class DBconnection {
	public static Connection getConn() throws Exception {
		Connection conn = null;
		Class.forName("oracle.jdbc.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "1234");
		System.out.println("����");
		return conn;
	}
	public static ResultSet getSql(String sql) throws Exception{
		ResultSet rs = null;
		Connection conn=getConn();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		System.out.println(sql);
		return rs;
	}
}
