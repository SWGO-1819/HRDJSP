package model;

import java.sql.SQLException;
import java.util.List;

public class SampleDAOmpl implements SampleDAO {

	@Override
	public int create(SampleVO vo) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public SampleVO readOn(SampleVO vo) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SampleVO> readList() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int Update(SampleVO vo) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(SampleVO vo) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

}
