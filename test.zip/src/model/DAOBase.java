package model;

import java.sql.*;
import java.sql.DriverManager;

public class DAOBase implements DAO{
	public Connection getConnection() throws SQLException {
		Connection conn = null;
		try {
		String jdbc_driver="oralce.jdbc.OracleDriver";
		String db_url="jdbc:oracle:thin:@localhost:1521:xe";
		Class.forName(jdbc_driver);
		conn=DriverManager.getConnection(db_url,"system", "1234");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public void closeDBResources(ResultSet rs,Statement stmt, Connection conn) {
		if(rs!=null) {
			try {
				rs.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(stmt!=null) {
			try {
				rs.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				rs.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
