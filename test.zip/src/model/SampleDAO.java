package model;

import java.sql.SQLException;
import java.util.List;

public interface SampleDAO {
int create(SampleVO vo) throws SQLException;
SampleVO readOn(SampleVO vo) throws SQLException;
List<SampleVO> readList() throws SQLException;
int Update(SampleVO vo) throws SQLException;
int delete(SampleVO vo) throws SQLException;
}
