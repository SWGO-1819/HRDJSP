package DBPKG;
import java.sql.*;
public class dbconnection {
	public static Connection getconn() throws Exception{
		Connection conn=null;
		Class.forName("oracle.jdbc.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","asd123");
		return conn;
	}
	public static ResultSet getsql(String sql) throws Exception{
		ResultSet rs=null;
		Connection conn = getconn();
		System.out.println(sql);
		PreparedStatement pstmt = conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		return rs;
	}
}
