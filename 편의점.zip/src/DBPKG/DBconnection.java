package DBPKG;
import java.sql.*;
public class DBconnection {
	public static Connection getcon() throws Exception{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		return con;
	}
	public static ResultSet getsql(String sql) throws Exception{
		PreparedStatement pstmt = getcon().prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		return rs;
	}
}
